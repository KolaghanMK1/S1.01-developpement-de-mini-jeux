var structregister___cardgame____the__war =
[
    [ "register_Cardgame__the_war", "structregister___cardgame____the__war.html#a3f91883a732a1bda4fd66c6d57ef815c", null ]
];