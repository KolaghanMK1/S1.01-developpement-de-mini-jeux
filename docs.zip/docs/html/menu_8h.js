var menu_8h =
[
    [ "game", "structgame.html", "structgame" ],
    [ "addGame", "menu_8h.html#ad2252d3020620b488d9b3b9f5b83636b", null ],
    [ "getGameList", "menu_8h.html#a0bc16237fd107a7a2bfad957c22686de", null ]
];