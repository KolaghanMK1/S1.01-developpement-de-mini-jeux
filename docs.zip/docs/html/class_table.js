var class_table =
[
    [ "Card", "class_table.html#ace175873ac80ba3464b6720591bd602b", null ],
    [ "get_table", "class_table.html#a1fe6f89aa0476378ca8167c2c8c3b060", null ],
    [ "put_on_table", "class_table.html#a93712a6bf405bd9fad5e6b4eff3b8548", null ],
    [ "take_from_table", "class_table.html#a09e9f2b598c1afa813e16e1dcd54e3b0", null ],
    [ "on_table", "class_table.html#a579b345d1277926db48ac6e7f4822990", null ],
    [ "v_on_table", "class_table.html#a6d3ae8320052c4e2ef4469eb7e80e7c5", null ]
];