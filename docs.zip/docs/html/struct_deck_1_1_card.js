var struct_deck_1_1_card =
[
    [ "Card", "struct_deck_1_1_card.html#ad5c078af12185839032b7c3eacdd1593", null ],
    [ "Card", "struct_deck_1_1_card.html#aa728d8307be8f0475ad385b03b82da00", null ],
    [ "make_key", "struct_deck_1_1_card.html#a5f9c98c9b496f5d6476b20f01c1dd042", null ],
    [ "operator==", "struct_deck_1_1_card.html#ad8ae45288f902030b1973f8317e478bf", null ],
    [ "suit", "struct_deck_1_1_card.html#abb06aebfce62cebc34f8f3dd1eb65bd8", null ],
    [ "value", "struct_deck_1_1_card.html#af8f3cf84f533306dfc66a0aed52aa83d", null ]
];