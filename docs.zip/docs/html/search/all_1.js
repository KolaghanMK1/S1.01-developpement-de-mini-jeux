var searchData=
[
  ['build_0',['build',['../class_deck.html#a9d51beb30c6038f03840e042c9a7870b',1,'Deck']]]
];
