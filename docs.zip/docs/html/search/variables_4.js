var searchData=
[
  ['hand_0',['hand',['../class_player.html#ac154ba3a1f4dcc0484170d510c5619df',1,'Player']]]
];
