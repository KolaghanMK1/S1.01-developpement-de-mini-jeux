var searchData=
[
  ['registergameinstance_0',['registerGameInstance',['../card__game__-__the__war_8cpp.html#a97be812f9ad710a28004fec599bee7c2',1,'registerGameInstance:&#160;card_game_-_the_war.cpp'],['../_chifoumi_8cpp.html#a4cf8a7c2452b93f6f4966944810b56e3',1,'registerGameInstance:&#160;Chifoumi.cpp'],['../morpion_8cpp.html#abe7f021a38ad2f837f0b46a4daa8057b',1,'registerGameInstance:&#160;morpion.cpp'],['../pendu_8cpp.html#af5ffe815548bb913f2b83dde6c19c5dc',1,'registerGameInstance:&#160;pendu.cpp']]],
  ['render_1',['render',['../class_t_u_i___core.html#aba23a562b5123ea59d23e7f78340bb17',1,'TUI_Core']]]
];
