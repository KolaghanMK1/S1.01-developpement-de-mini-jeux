var searchData=
[
  ['card_0',['Card',['../class_player.html#a093fef009216ba2f9c82f404163158be',1,'Player::Card'],['../class_table.html#ace175873ac80ba3464b6720591bd602b',1,'Table::Card']]]
];
