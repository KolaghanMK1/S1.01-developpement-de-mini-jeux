var searchData=
[
  ['v_5fon_5ftable_0',['v_on_table',['../class_table.html#a6d3ae8320052c4e2ef4469eb7e80e7c5',1,'Table']]],
  ['value_1',['value',['../struct_deck_1_1_card.html#af8f3cf84f533306dfc66a0aed52aa83d',1,'Deck::Card']]]
];
