var searchData=
[
  ['add_5fcard_5fto_5fhand_0',['add_card_to_hand',['../class_player.html#ad12af05e7a75dff1e7310c83c4d75294',1,'Player']]],
  ['addgame_1',['addGame',['../menu_8cpp.html#a6edea5f8d64d3be9a68fcf6ea6fc12a3',1,'addGame(const string &amp;name, function&lt; void()&gt; launchFunction):&#160;menu.cpp'],['../menu_8h.html#ad2252d3020620b488d9b3b9f5b83636b',1,'addGame(const std::string &amp;name, std::function&lt; void()&gt; launchFunction):&#160;menu.h']]],
  ['affichage_5fmorpion_2',['affichage_morpion',['../morpion_8cpp.html#a22252c81e45aca427ce8f2519446ab7e',1,'morpion.cpp']]]
];
