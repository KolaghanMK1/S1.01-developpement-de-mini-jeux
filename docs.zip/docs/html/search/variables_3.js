var searchData=
[
  ['g_5fmanual_5fmode_0',['g_manual_mode',['../card__game__-__the__war_8cpp.html#af934cfbab2a5cf26017426d29a753f20',1,'card_game_-_the_war.cpp']]],
  ['g_5fspecial_5frules_1',['g_special_rules',['../card__game__-__the__war_8cpp.html#ae46f456254acd0b467e63b8aa68d4d43',1,'card_game_-_the_war.cpp']]]
];
