var searchData=
[
  ['file_0',['file',['../struct_t_u_i___core_1_1_key_structure.html#a3d9b71236c0c4f2fd649b985c6bb3912',1,'TUI_Core::KeyStructure']]],
  ['formatmaj_1',['formatMAJ',['../pendu_8cpp.html#a1c3ec8b24fe9ff92a1d955067a2133e8',1,'pendu.cpp']]]
];
