var searchData=
[
  ['take_5ffrom_5ftable_0',['take_from_table',['../class_table.html#a09e9f2b598c1afa813e16e1dcd54e3b0',1,'Table']]],
  ['the_5fwar_5fmenu_1',['the_war_Menu',['../card__game__-__the__war_8cpp.html#afe2f0b3fc630ceae985752494493d64a',1,'card_game_-_the_war.cpp']]],
  ['tui_5fcore_2',['TUI_Core',['../class_t_u_i___core.html#a59d85d8f6a895ec5290bf7e0f824e667',1,'TUI_Core']]],
  ['tui_5frender_3',['TUI_Render',['../class_t_u_i___core_1_1_t_u_i___render.html#a402b63ee7f6507f9d5583bec515a9c4b',1,'TUI_Core::TUI_Render']]]
];
