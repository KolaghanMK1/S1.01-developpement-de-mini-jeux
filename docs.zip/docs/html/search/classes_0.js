var searchData=
[
  ['card_0',['Card',['../struct_deck_1_1_card.html',1,'Deck']]]
];
