var searchData=
[
  ['register_5fcardgame_5f_5fthe_5fwar_0',['register_Cardgame__the_war',['../structregister___cardgame____the__war.html',1,'']]],
  ['register_5fchifoumi_1',['register_chifoumi',['../structregister__chifoumi.html',1,'']]],
  ['register_5fmorpion_2',['register_morpion',['../structregister__morpion.html',1,'']]],
  ['registerpendu_3',['registerPendu',['../structregister_pendu.html',1,'']]]
];
