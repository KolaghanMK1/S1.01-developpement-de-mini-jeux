var menu_8cpp =
[
    [ "addGame", "menu_8cpp.html#a6edea5f8d64d3be9a68fcf6ea6fc12a3", null ],
    [ "credits", "menu_8cpp.html#a46b44fefe3ce62538e674a759af226b4", null ],
    [ "getGameList", "menu_8cpp.html#ade17666827be5d7a3e1a3a98d4bdb1de", null ],
    [ "listGames", "menu_8cpp.html#a80fbf10d82fa7d4e2be334644c33dfcb", null ],
    [ "main", "menu_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ],
    [ "mainMenu", "menu_8cpp.html#ab3002fe8e0074c9e2ecb5b835e5e819f", null ],
    [ "Menu", "menu_8cpp.html#a61c1b39c84b3888f8cd4b2197d4ea1ff", null ],
    [ "settings", "menu_8cpp.html#a2942de2f896d38d79bad0edb31016209", null ],
    [ "MainMenu", "menu_8cpp.html#ac3bc9d802c15ff8b6600f3d10b5e6a84", null ]
];