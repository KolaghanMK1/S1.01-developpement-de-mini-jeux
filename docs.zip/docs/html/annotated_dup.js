var annotated_dup =
[
    [ "Deck", "class_deck.html", "class_deck" ],
    [ "game", "structgame.html", "structgame" ],
    [ "Player", "class_player.html", "class_player" ],
    [ "register_Cardgame__the_war", "structregister___cardgame____the__war.html", "structregister___cardgame____the__war" ],
    [ "register_chifoumi", "structregister__chifoumi.html", "structregister__chifoumi" ],
    [ "register_morpion", "structregister__morpion.html", "structregister__morpion" ],
    [ "registerPendu", "structregister_pendu.html", "structregister_pendu" ],
    [ "Table", "class_table.html", "class_table" ],
    [ "TUI_Core", "class_t_u_i___core.html", "class_t_u_i___core" ]
];