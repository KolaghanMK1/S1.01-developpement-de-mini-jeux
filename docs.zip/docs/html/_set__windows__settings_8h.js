var _set__windows__settings_8h =
[
    [ "EnableANSIColors", "_set__windows__settings_8h.html#aba7460329924327f087821dd8ddbe5e7", null ],
    [ "EnableUTF8", "_set__windows__settings_8h.html#aa9a59abd349dc78d56b1b0bcc3f852fd", null ]
];