var class_player =
[
    [ "Card", "class_player.html#a093fef009216ba2f9c82f404163158be", null ],
    [ "add_card_to_hand", "class_player.html#ad12af05e7a75dff1e7310c83c4d75294", null ],
    [ "get_cards_in_hand", "class_player.html#a7714c5bd50729d056e0bebc77b4f3e60", null ],
    [ "get_nb_card_handed", "class_player.html#a78cac43c14705da6fcf3e2430a6260db", null ],
    [ "play", "class_player.html#ae488b4b42134c5dcac31225deea55397", null ],
    [ "play", "class_player.html#aaf71508152d7614f78bad224bd32cea9", null ],
    [ "cards_in_hand", "class_player.html#ade6b560130d42593756b0b7c0e2aff1c", null ],
    [ "hand", "class_player.html#ac154ba3a1f4dcc0484170d510c5619df", null ]
];