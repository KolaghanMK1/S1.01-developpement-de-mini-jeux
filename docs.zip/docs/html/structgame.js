var structgame =
[
    [ "game", "structgame.html#a0f2645eb403dcbe70dabd2bcf2649adf", null ],
    [ "launchFunction", "structgame.html#a1fd82659ba9238f39da10815b84b98c5", null ],
    [ "name", "structgame.html#a252b06af5466a21270d4127a581e1546", null ]
];