var _chifoumi_8cpp =
[
    [ "register_chifoumi", "structregister__chifoumi.html", "structregister__chifoumi" ],
    [ "play_chifoumi", "_chifoumi_8cpp.html#a3b9133e2bd59a2997bfcb22e01f57742", null ],
    [ "registerGameInstance", "_chifoumi_8cpp.html#a4cf8a7c2452b93f6f4966944810b56e3", null ]
];